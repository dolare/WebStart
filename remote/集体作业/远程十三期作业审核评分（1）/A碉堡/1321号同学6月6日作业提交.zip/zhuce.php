<?php

      header('Content-Type:text/html;charset=utf-8');

    echo '<pre>';

    print_r($_POST);
	
    echo '</pre>';


    ?>
<h2>请记住您的注册信息，5秒钟后跳转至首页</h2>
<!-- 设置页面5秒后跳转至注册成功页面 -->
<meta http-equiv="refresh" content="5;url=gongxinin.html">

    
